![image](https://github.com/developerrahulofficial/calling-jadoo/assets/83329806/9a3ff736-371d-4934-98eb-39a0a8bc6556)# calling-jadoo

this is just a stimulator of calling jadoo inspired by movie "Koi mil gaya"

Here are somescreenshots :
 ![image](https://github.com/developerrahulofficial/calling-jadoo/assets/83329806/5feccada-a2e9-4092-b084-c03bbf85a5af)


When you press keys : 
it also do sound "oo ohh oo oooo"  😂

Thanks and follow me on my social handles :

Insta : https://www.instagram.com/developer_rahul_/
Youtube : https://www.youtube.com/@developerRahul
